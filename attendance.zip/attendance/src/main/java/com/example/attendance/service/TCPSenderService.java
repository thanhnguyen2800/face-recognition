package com.example.attendance.service;

import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Service;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
public class TCPSenderService {
    private static final Logger logger = LoggerFactory.getLogger(TCPSenderService.class);
    private ServerSocket serverSocket;
    private Socket clientSocket;
    private PrintWriter writer;

    @PostConstruct
    public void init() {
        try {
            serverSocket = new ServerSocket(8584);
        } catch (IOException e) {
            logger.error(e.getMessage());
        }
    }

    public void connect() {
        try {
            if (clientSocket == null || clientSocket.isClosed()) {
                clientSocket = serverSocket.accept();
                writer = new PrintWriter(clientSocket.getOutputStream(), true);
            }
        } catch (IOException e) {
            logger.error(e.getMessage());
        }
    }

    public void sendData(String message) {
        if (clientSocket != null && !clientSocket.isClosed() && writer != null) {
            writer.println(message);
        } else {
            connect();
            if (clientSocket != null && !clientSocket.isClosed() && writer != null) {
                writer.println(message);
            }
        }
    }
}